# FormFirebaseAuth
1. Form with flutter https://docs.flutter.dev/cookbook/forms/validation
2. configure Firebase https://firebase.google.com/docs/flutter/setup?platform=android
3. authentification firebase https://firebase.google.com/docs/auth/flutter/password-auth
